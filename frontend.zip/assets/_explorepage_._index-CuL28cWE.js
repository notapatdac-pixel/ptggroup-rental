import{r as e,t}from"./rolldown-runtime-ZTEY5dKY.js";import{A as n,j as r,r as i}from"./chunk-JZWAC4HX-CGjl1QJ4.js";import"./react-dom-lw6dtffu.js";import{a,i as o,n as s,s as c,y as l}from"./esm-BfqTSlGm.js";import{n as u}from"./emotion-react.browser.esm-CFzz9P1A.js";var d=t(((e,t)=>{t.exports=`SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED`})),f=t(((e,t)=>{var n=d();function r(){}function i(){}i.resetWarningCache=r,t.exports=function(){function e(e,t,r,i,a,o){if(o!==n){var s=Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw s.name=`Invariant Violation`,s}}e.isRequired=e;function t(){return e}var a={array:e,bigint:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:t,element:e,elementType:e,instanceOf:t,node:e,objectOf:t,oneOf:t,oneOfType:t,shape:t,exact:t,checkPropTypes:i,resetWarningCache:r};return a.PropTypes=a,a}})),p=t(((e,t)=>{t.exports=f()()})),m=t(((e,t)=>{function n(e){return e&&typeof e==`object`&&`default`in e?e.default:e}var i=r(),a=n(i);function o(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function s(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e,e.__proto__=t}var c=!!(typeof window<`u`&&window.document&&window.document.createElement);function l(e,t,n){if(typeof e!=`function`)throw Error(`Expected reducePropsToState to be a function.`);if(typeof t!=`function`)throw Error(`Expected handleStateChangeOnClient to be a function.`);if(n!==void 0&&typeof n!=`function`)throw Error(`Expected mapStateOnServer to either be undefined or a function.`);function r(e){return e.displayName||e.name||`Component`}return function(l){if(typeof l!=`function`)throw Error(`Expected WrappedComponent to be a React component.`);var u=[],d;function f(){d=e(u.map(function(e){return e.props})),p.canUseDOM?t(d):n&&(d=n(d))}var p=function(e){s(t,e);function t(){return e.apply(this,arguments)||this}t.peek=function(){return d},t.rewind=function(){if(t.canUseDOM)throw Error(`You may only call rewind() on the server. Call peek() to read the current state.`);var e=d;return d=void 0,u=[],e};var n=t.prototype;return n.UNSAFE_componentWillMount=function(){u.push(this),f()},n.componentDidUpdate=function(){f()},n.componentWillUnmount=function(){var e=u.indexOf(this);u.splice(e,1),f()},n.render=function(){return a.createElement(l,this.props)},t}(i.PureComponent);return o(p,`displayName`,`SideEffect(`+r(l)+`)`),o(p,`canUseDOM`,c),p}}t.exports=l})),h=t(((e,t)=>{var n=typeof Element<`u`,r=typeof Map==`function`,i=typeof Set==`function`,a=typeof ArrayBuffer==`function`&&!!ArrayBuffer.isView;function o(e,t){if(e===t)return!0;if(e&&t&&typeof e==`object`&&typeof t==`object`){if(e.constructor!==t.constructor)return!1;var s,c,l;if(Array.isArray(e)){if(s=e.length,s!=t.length)return!1;for(c=s;c--!==0;)if(!o(e[c],t[c]))return!1;return!0}var u;if(r&&e instanceof Map&&t instanceof Map){if(e.size!==t.size)return!1;for(u=e.entries();!(c=u.next()).done;)if(!t.has(c.value[0]))return!1;for(u=e.entries();!(c=u.next()).done;)if(!o(c.value[1],t.get(c.value[0])))return!1;return!0}if(i&&e instanceof Set&&t instanceof Set){if(e.size!==t.size)return!1;for(u=e.entries();!(c=u.next()).done;)if(!t.has(c.value[0]))return!1;return!0}if(a&&ArrayBuffer.isView(e)&&ArrayBuffer.isView(t)){if(s=e.length,s!=t.length)return!1;for(c=s;c--!==0;)if(e[c]!==t[c])return!1;return!0}if(e.constructor===RegExp)return e.source===t.source&&e.flags===t.flags;if(e.valueOf!==Object.prototype.valueOf&&typeof e.valueOf==`function`&&typeof t.valueOf==`function`)return e.valueOf()===t.valueOf();if(e.toString!==Object.prototype.toString&&typeof e.toString==`function`&&typeof t.toString==`function`)return e.toString()===t.toString();if(l=Object.keys(e),s=l.length,s!==Object.keys(t).length)return!1;for(c=s;c--!==0;)if(!Object.prototype.hasOwnProperty.call(t,l[c]))return!1;if(n&&e instanceof Element)return!1;for(c=s;c--!==0;)if(!((l[c]===`_owner`||l[c]===`__v`||l[c]===`__o`)&&e.$$typeof)&&!o(e[l[c]],t[l[c]]))return!1;return!0}return e!==e&&t!==t}t.exports=function(e,t){try{return o(e,t)}catch(e){if((e.message||``).match(/stack|recursion/i))return console.warn(`react-fast-compare cannot handle circular refs`),!1;throw e}}})),g=t(((e,t)=>{var n=Object.getOwnPropertySymbols,r=Object.prototype.hasOwnProperty,i=Object.prototype.propertyIsEnumerable;function a(e){if(e==null)throw TypeError(`Object.assign cannot be called with null or undefined`);return Object(e)}function o(){try{if(!Object.assign)return!1;var e=new String(`abc`);if(e[5]=`de`,Object.getOwnPropertyNames(e)[0]===`5`)return!1;for(var t={},n=0;n<10;n++)t[`_`+String.fromCharCode(n)]=n;if(Object.getOwnPropertyNames(t).map(function(e){return t[e]}).join(``)!==`0123456789`)return!1;var r={};return`abcdefghijklmnopqrst`.split(``).forEach(function(e){r[e]=e}),Object.keys(Object.assign({},r)).join(``)===`abcdefghijklmnopqrst`}catch{return!1}}t.exports=o()?Object.assign:function(e,t){for(var o,s=a(e),c,l=1;l<arguments.length;l++){for(var u in o=Object(arguments[l]),o)r.call(o,u)&&(s[u]=o[u]);if(n){c=n(o);for(var d=0;d<c.length;d++)i.call(o,c[d])&&(s[c[d]]=o[c[d]])}}return s}})),_=e(p()),v=e(m()),ee=e(h()),y=e(r()),b=e(g()),x={BODY:`bodyAttributes`,HTML:`htmlAttributes`,TITLE:`titleAttributes`},S={BASE:`base`,BODY:`body`,HEAD:`head`,HTML:`html`,LINK:`link`,META:`meta`,NOSCRIPT:`noscript`,SCRIPT:`script`,STYLE:`style`,TITLE:`title`};Object.keys(S).map(function(e){return S[e]});var C={CHARSET:`charset`,CSS_TEXT:`cssText`,HREF:`href`,HTTPEQUIV:`http-equiv`,INNER_HTML:`innerHTML`,ITEM_PROP:`itemprop`,NAME:`name`,PROPERTY:`property`,REL:`rel`,SRC:`src`,TARGET:`target`},w={accesskey:`accessKey`,charset:`charSet`,class:`className`,contenteditable:`contentEditable`,contextmenu:`contextMenu`,"http-equiv":`httpEquiv`,itemprop:`itemProp`,tabindex:`tabIndex`},T={DEFAULT_TITLE:`defaultTitle`,DEFER:`defer`,ENCODE_SPECIAL_CHARACTERS:`encodeSpecialCharacters`,ON_CHANGE_CLIENT_STATE:`onChangeClientState`,TITLE_TEMPLATE:`titleTemplate`},E=Object.keys(w).reduce(function(e,t){return e[w[t]]=t,e},{}),D=[S.NOSCRIPT,S.SCRIPT,S.STYLE],O=`data-react-helmet`,k=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},te=function(e,t){if(!(e instanceof t))throw TypeError(`Cannot call a class as a function`)},ne=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,`value`in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),A=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},re=function(e,t){if(typeof t!=`function`&&t!==null)throw TypeError(`Super expression must either be null or a function, not `+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)},j=function(e,t){var n={};for(var r in e)t.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(e,r)&&(n[r]=e[r]);return n},ie=function(e,t){if(!e)throw ReferenceError(`this hasn't been initialised - super() hasn't been called`);return t&&(typeof t==`object`||typeof t==`function`)?t:e},M=function(e){return(arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0)===!1?String(e):String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#x27;`)},N=function(e){var t=R(e,S.TITLE),n=R(e,T.TITLE_TEMPLATE);if(n&&t)return n.replace(/%s/g,function(){return Array.isArray(t)?t.join(``):t});var r=R(e,T.DEFAULT_TITLE);return t||r||void 0},P=function(e){return R(e,T.ON_CHANGE_CLIENT_STATE)||function(){}},F=function(e,t){return t.filter(function(t){return t[e]!==void 0}).map(function(t){return t[e]}).reduce(function(e,t){return A({},e,t)},{})},I=function(e,t){return t.filter(function(e){return e[S.BASE]!==void 0}).map(function(e){return e[S.BASE]}).reverse().reduce(function(t,n){if(!t.length)for(var r=Object.keys(n),i=0;i<r.length;i++){var a=r[i].toLowerCase();if(e.indexOf(a)!==-1&&n[a])return t.concat(n)}return t},[])},L=function(e,t,n){var r={};return n.filter(function(t){return Array.isArray(t[e])?!0:(t[e]!==void 0&&ae(`Helmet: `+e+` should be of type "Array". Instead found type "`+k(t[e])+`"`),!1)}).map(function(t){return t[e]}).reverse().reduce(function(e,n){var i={};n.filter(function(e){for(var n=void 0,a=Object.keys(e),o=0;o<a.length;o++){var s=a[o],c=s.toLowerCase();t.indexOf(c)!==-1&&!(n===C.REL&&e[n].toLowerCase()===`canonical`)&&!(c===C.REL&&e[c].toLowerCase()===`stylesheet`)&&(n=c),t.indexOf(s)!==-1&&(s===C.INNER_HTML||s===C.CSS_TEXT||s===C.ITEM_PROP)&&(n=s)}if(!n||!e[n])return!1;var l=e[n].toLowerCase();return r[n]||(r[n]={}),i[n]||(i[n]={}),r[n][l]?!1:(i[n][l]=!0,!0)}).reverse().forEach(function(t){return e.push(t)});for(var a=Object.keys(i),o=0;o<a.length;o++){var s=a[o];r[s]=(0,b.default)({},r[s],i[s])}return e},[]).reverse()},R=function(e,t){for(var n=e.length-1;n>=0;n--){var r=e[n];if(r.hasOwnProperty(t))return r[t]}return null},z=function(e){return{baseTag:I([C.HREF,C.TARGET],e),bodyAttributes:F(x.BODY,e),defer:R(e,T.DEFER),encode:R(e,T.ENCODE_SPECIAL_CHARACTERS),htmlAttributes:F(x.HTML,e),linkTags:L(S.LINK,[C.REL,C.HREF],e),metaTags:L(S.META,[C.NAME,C.CHARSET,C.HTTPEQUIV,C.PROPERTY,C.ITEM_PROP],e),noscriptTags:L(S.NOSCRIPT,[C.INNER_HTML],e),onChangeClientState:P(e),scriptTags:L(S.SCRIPT,[C.SRC,C.INNER_HTML],e),styleTags:L(S.STYLE,[C.CSS_TEXT],e),title:N(e),titleAttributes:F(x.TITLE,e)}},B=function(){var e=Date.now();return function(t){var n=Date.now();n-e>16?(e=n,t(n)):setTimeout(function(){B(t)},0)}}(),V=function(e){return clearTimeout(e)},H=typeof window<`u`?window.requestAnimationFrame&&window.requestAnimationFrame.bind(window)||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||B:global.requestAnimationFrame||B,U=typeof window<`u`?window.cancelAnimationFrame||window.webkitCancelAnimationFrame||window.mozCancelAnimationFrame||V:global.cancelAnimationFrame||V,ae=function(e){return console&&typeof console.warn==`function`&&console.warn(e)},W=null,oe=function(e){W&&U(W),e.defer?W=H(function(){G(e,function(){W=null})}):(G(e),W=null)},G=function(e,t){var n=e.baseTag,r=e.bodyAttributes,i=e.htmlAttributes,a=e.linkTags,o=e.metaTags,s=e.noscriptTags,c=e.onChangeClientState,l=e.scriptTags,u=e.styleTags,d=e.title,f=e.titleAttributes;q(S.BODY,r),q(S.HTML,i),se(d,f);var p={baseTag:J(S.BASE,n),linkTags:J(S.LINK,a),metaTags:J(S.META,o),noscriptTags:J(S.NOSCRIPT,s),scriptTags:J(S.SCRIPT,l),styleTags:J(S.STYLE,u)},m={},h={};Object.keys(p).forEach(function(e){var t=p[e],n=t.newTags,r=t.oldTags;n.length&&(m[e]=n),r.length&&(h[e]=p[e].oldTags)}),t&&t(),c(e,m,h)},K=function(e){return Array.isArray(e)?e.join(``):e},se=function(e,t){e!==void 0&&document.title!==e&&(document.title=K(e)),q(S.TITLE,t)},q=function(e,t){var n=document.getElementsByTagName(e)[0];if(n){for(var r=n.getAttribute(O),i=r?r.split(`,`):[],a=[].concat(i),o=Object.keys(t),s=0;s<o.length;s++){var c=o[s],l=t[c]||``;n.getAttribute(c)!==l&&n.setAttribute(c,l),i.indexOf(c)===-1&&i.push(c);var u=a.indexOf(c);u!==-1&&a.splice(u,1)}for(var d=a.length-1;d>=0;d--)n.removeAttribute(a[d]);i.length===a.length?n.removeAttribute(O):n.getAttribute(O)!==o.join(`,`)&&n.setAttribute(O,o.join(`,`))}},J=function(e,t){var n=document.head||document.querySelector(S.HEAD),r=n.querySelectorAll(e+`[`+O+`]`),i=Array.prototype.slice.call(r),a=[],o=void 0;return t&&t.length&&t.forEach(function(t){var n=document.createElement(e);for(var r in t)if(t.hasOwnProperty(r))if(r===C.INNER_HTML)n.innerHTML=t.innerHTML;else if(r===C.CSS_TEXT)n.styleSheet?n.styleSheet.cssText=t.cssText:n.appendChild(document.createTextNode(t.cssText));else{var s=t[r]===void 0?``:t[r];n.setAttribute(r,s)}n.setAttribute(O,`true`),i.some(function(e,t){return o=t,n.isEqualNode(e)})?i.splice(o,1):a.push(n)}),i.forEach(function(e){return e.parentNode.removeChild(e)}),a.forEach(function(e){return n.appendChild(e)}),{oldTags:i,newTags:a}},Y=function(e){return Object.keys(e).reduce(function(t,n){var r=e[n]===void 0?``+n:n+`="`+e[n]+`"`;return t?t+` `+r:r},``)},ce=function(e,t,n,r){var i=Y(n),a=K(t);return i?`<`+e+` `+O+`="true" `+i+`>`+M(a,r)+`</`+e+`>`:`<`+e+` `+O+`="true">`+M(a,r)+`</`+e+`>`},le=function(e,t,n){return t.reduce(function(t,r){var i=Object.keys(r).filter(function(e){return!(e===C.INNER_HTML||e===C.CSS_TEXT)}).reduce(function(e,t){var i=r[t]===void 0?t:t+`="`+M(r[t],n)+`"`;return e?e+` `+i:i},``),a=r.innerHTML||r.cssText||``,o=D.indexOf(e)===-1;return t+`<`+e+` `+O+`="true" `+i+(o?`/>`:`>`+a+`</`+e+`>`)},``)},X=function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};return Object.keys(e).reduce(function(t,n){return t[w[n]||n]=e[n],t},t)},ue=function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};return Object.keys(e).reduce(function(t,n){return t[E[n]||n]=e[n],t},t)},de=function(e,t,n){var r,i=X(n,(r={key:t},r[O]=!0,r));return[y.createElement(S.TITLE,i,t)]},fe=function(e,t){return t.map(function(t,n){var r,i=(r={key:n},r[O]=!0,r);return Object.keys(t).forEach(function(e){var n=w[e]||e;n===C.INNER_HTML||n===C.CSS_TEXT?i.dangerouslySetInnerHTML={__html:t.innerHTML||t.cssText}:i[n]=t[e]}),y.createElement(e,i)})},Z=function(e,t,n){switch(e){case S.TITLE:return{toComponent:function(){return de(e,t.title,t.titleAttributes,n)},toString:function(){return ce(e,t.title,t.titleAttributes,n)}};case x.BODY:case x.HTML:return{toComponent:function(){return X(t)},toString:function(){return Y(t)}};default:return{toComponent:function(){return fe(e,t)},toString:function(){return le(e,t,n)}}}},Q=function(e){var t=e.baseTag,n=e.bodyAttributes,r=e.encode,i=e.htmlAttributes,a=e.linkTags,o=e.metaTags,s=e.noscriptTags,c=e.scriptTags,l=e.styleTags,u=e.title,d=u===void 0?``:u,f=e.titleAttributes;return{base:Z(S.BASE,t,r),bodyAttributes:Z(x.BODY,n,r),htmlAttributes:Z(x.HTML,i,r),link:Z(S.LINK,a,r),meta:Z(S.META,o,r),noscript:Z(S.NOSCRIPT,s,r),script:Z(S.SCRIPT,c,r),style:Z(S.STYLE,l,r),title:Z(S.TITLE,{title:d,titleAttributes:f},r)}},$=function(e){var t,n;return n=t=function(t){re(n,t);function n(){return te(this,n),ie(this,t.apply(this,arguments))}return n.prototype.shouldComponentUpdate=function(e){return!(0,ee.default)(this.props,e)},n.prototype.mapNestedChildrenToProps=function(e,t){if(!t)return null;switch(e.type){case S.SCRIPT:case S.NOSCRIPT:return{innerHTML:t};case S.STYLE:return{cssText:t}}throw Error(`<`+e.type+` /> elements are self-closing and can not contain children. Refer to our API for more information.`)},n.prototype.flattenArrayTypeChildren=function(e){var t,n=e.child,r=e.arrayTypeChildren,i=e.newChildProps,a=e.nestedChildren;return A({},r,(t={},t[n.type]=[].concat(r[n.type]||[],[A({},i,this.mapNestedChildrenToProps(n,a))]),t))},n.prototype.mapObjectTypeChildren=function(e){var t,n,r=e.child,i=e.newProps,a=e.newChildProps,o=e.nestedChildren;switch(r.type){case S.TITLE:return A({},i,(t={},t[r.type]=o,t.titleAttributes=A({},a),t));case S.BODY:return A({},i,{bodyAttributes:A({},a)});case S.HTML:return A({},i,{htmlAttributes:A({},a)})}return A({},i,(n={},n[r.type]=A({},a),n))},n.prototype.mapArrayTypeChildrenToProps=function(e,t){var n=A({},t);return Object.keys(e).forEach(function(t){var r;n=A({},n,(r={},r[t]=e[t],r))}),n},n.prototype.warnOnInvalidChildren=function(e,t){return!0},n.prototype.mapChildrenToProps=function(e,t){var n=this,r={};return y.Children.forEach(e,function(e){if(!(!e||!e.props)){var i=e.props,a=i.children,o=ue(j(i,[`children`]));switch(n.warnOnInvalidChildren(e,a),e.type){case S.LINK:case S.META:case S.NOSCRIPT:case S.SCRIPT:case S.STYLE:r=n.flattenArrayTypeChildren({child:e,arrayTypeChildren:r,newChildProps:o,nestedChildren:a});break;default:t=n.mapObjectTypeChildren({child:e,newProps:t,newChildProps:o,nestedChildren:a});break}}}),t=this.mapArrayTypeChildrenToProps(r,t),t},n.prototype.render=function(){var t=this.props,n=t.children,r=A({},j(t,[`children`]));return n&&(r=this.mapChildrenToProps(n,r)),y.createElement(e,r)},ne(n,null,[{key:`canUseDOM`,set:function(t){e.canUseDOM=t}}]),n}(y.Component),t.propTypes={base:_.default.object,bodyAttributes:_.default.object,children:_.default.oneOfType([_.default.arrayOf(_.default.node),_.default.node]),defaultTitle:_.default.string,defer:_.default.bool,encodeSpecialCharacters:_.default.bool,htmlAttributes:_.default.object,link:_.default.arrayOf(_.default.object),meta:_.default.arrayOf(_.default.object),noscript:_.default.arrayOf(_.default.object),onChangeClientState:_.default.func,script:_.default.arrayOf(_.default.object),style:_.default.arrayOf(_.default.object),title:_.default.string,titleAttributes:_.default.object,titleTemplate:_.default.string},t.defaultProps={defer:!0,encodeSpecialCharacters:!0},t.peek=e.peek,t.rewind=function(){var t=e.rewind();return t||=Q({baseTag:[],bodyAttributes:{},encodeSpecialCharacters:!0,htmlAttributes:{},linkTags:[],metaTags:[],noscriptTags:[],scriptTags:[],styleTags:[],title:``,titleAttributes:{}}),t},n}((0,v.default)(z,oe,Q)(function(){return null}));$.renderStatic=$.rewind;var pe=n(function(){let e=(0,y.useRef)(null);l.ref_ptg_explore_search_input=e;let t=(0,y.useRef)(null);l.ref_ptg_explore_leaflet_map=t;let n=(0,y.useRef)(null);l.ref_ptg_explore_zoom_in_btn=n;let r=(0,y.useRef)(null);l.ref_ptg_explore_zoom_out_btn=r;let d=(0,y.useRef)(null);l.ref_ptg_explore_loc_btn=d;let f=(0,y.useRef)(null);l.ref_ptg_explore_filter_province=f;let p=(0,y.useRef)(null);l.ref_ptg_explore_filter_traffic=p;let m=(0,y.useRef)(null);l.ref_ptg_explore_filter_spaces=m;let h=(0,y.useRef)(null);l.ref_ptg_station_card_latphrao71=h;let g=(0,y.useRef)(null);l.ref_ptg_station_card_ramaix=g;let _=(0,y.useRef)(null);return l.ref_ptg_station_card_bangna=_,u(y.Fragment,{},u(a,{},u(a,{className:`bg-surface text-on-surface antialiased overflow-hidden`},u(`nav`,{className:`fixed top-0 left-0 right-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md z-50 border-b border-outline-variant/10`},u(`div`,{className:`relative w-full`},u(o,{align:`start`,className:`rx-Stack w-full flex justify-between items-center px-8 h-20 relative z-10`,direction:`row`,gap:`3`},u(o,{align:`start`,className:`rx-Stack flex items-center gap-14`,direction:`row`,gap:`3`},u(s,{asChild:!0,className:`no-underline`,css:{"&:hover":{color:`var(--accent-8)`}}},u(i,{to:`/`},u(o,{align:`start`,className:`rx-Stack flex items-center gap-2`,direction:`row`,gap:`3`},u(c,{as:`p`,className:`text-4xl font-serif font-bold text-lime-500`},`PTG`),u(c,{as:`p`,className:`font-headline text-lg tracking-tight text-on-surface`},`Retail Platform`)))),u(o,{align:`start`,className:`rx-Stack hidden md:flex gap-10 items-center`,direction:`row`,gap:`3`},u(s,{asChild:!0,className:`nav-link-lime font-sans`,css:{"&:hover":{color:`var(--accent-8)`}}},u(i,{to:`/explorepage`},`Explore Locations`)),u(s,{asChild:!0,className:`nav-link-lime font-sans`,css:{"&:hover":{color:`var(--accent-8)`}}},u(i,{to:`/pricingpage`},`Pricing`)))),u(o,{align:`start`,className:`rx-Stack flex items-center gap-4`,direction:`row`,gap:`3`},u(`button`,{className:`btn-lime-ghost inline-flex items-center justify-center bg-transparent text-slate-600 dark:text-slate-400 font-sans text-sm px-4 py-2 border-0 cursor-pointer rounded-md transition-colors`,type:`button`},`Sign In`),u(`button`,{className:`inline-flex items-center justify-center primary-gradient text-white px-6 py-2.5 rounded-md text-sm font-bold shadow-sm border-0 cursor-pointer transition-all hover:shadow-lime-500/40 hover:ring-2 hover:ring-lime-300 hover:ring-offset-2 hover:ring-offset-white/80 active:scale-95`,type:`button`},`Get Started`))),u(`div`,{className:`pointer-events-none absolute inset-0 z-20 flex items-center justify-center`},u(`div`,{className:`pointer-events-auto relative group w-full max-w-2xl mx-auto transition-all duration-300 group-focus-within:max-w-5xl`},u(`span`,{className:`material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-outline group-focus-within:text-primary`},`search`),u(`input`,{className:`w-full bg-surface-container-low border-none rounded-full py-2.5 pl-12 pr-4 text-sm focus:ring-2 focus:ring-primary/20 transition-all outline-none`,id:`ptg-explore-search-input`,placeholder:`Search by province, station name, or district...`,ref:e,type:`text`}))))),u(`main`,{className:`flex h-screen pt-20`},u(`section`,{className:`flex-1 relative bg-surface-container-high overflow-hidden`},u(`section`,{className:`absolute inset-0 z-0`},u(`div`,{className:`relative w-full h-full`},u(`div`,{className:`absolute inset-0 w-full h-full z-0`,id:`ptg-explore-leaflet-map`,ref:t}),u(`div`,{className:`absolute inset-0 pointer-events-none map-gradient-overlay z-[1]`})),u($,{},u(`script`,{defer:!0,src:`https://unpkg.com/leaflet@1.9.4/dist/leaflet.js`})),u($,{},u(`script`,{defer:!0},`
    (() => {
      const markers = [{"id": "latphrao71", "title": "PTG Station Lat Phrao 71", "province": "Bangkok", "traffic_level": "high", "spaces_count": 3, "lat": 13.8046, "lng": 100.58, "location": "Bangkok \\u00b7 2.4 km away", "traffic_badge": "High Traffic", "match_badge": "98% Match", "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuAogYrPXv2k3xHfrvbGuzO2u9H021UfnjMDMLdrEuLu2gcWwSPbve71JZORUMDDO8zIqCI0qJ1BsPvzeI2XvXsUIlY9K58cfYcjOMUAWR2_i49F1_jWhThLLarbsBYMgxgc4v0VRqRj9eIjeaYHEFJuJHKGOCdjYH-9rNAX2Nh5sR-96NsIkkQicdlwhVgxMatMoIjNU8gdA3_D_drXtDmqGuAEX8DPF9T8cRvga1fGTTE_a2KHsAQ5jWufQ47tXLdN87UwcjOhK4Q"}, {"id": "ramaix", "title": "PTG Station Rama IX", "province": "Bangkok", "traffic_level": "medium", "spaces_count": 5, "lat": 13.75, "lng": 100.565, "location": "Bangkok \\u00b7 5.1 km away", "traffic_badge": "Medium Traffic", "match_badge": "92% Match", "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuB1XxKMY6FJqo6lJ8jPB-SDQcmEdz1BGe1moAtnxPkXaE82_zwaznYWAnNMvLgUTjz3bkjFvZeSOD-qBHB6XnZmYHrz9yTFk8xIw2xJWi8aN23rFnPM54otIauhJHSX5S_Uhz9OcmG9tRBR2XpLp0qdbts3bwiDPzho2Es8p_WCV7x1v_1HQ0UVhh4AjPQcbJKfIrLX3yFBdzQxm9pSBNvFh_kw6Ge_u_v818HARIcLfsm_P3S4Ku7CyHiA0rGDHIOLCRR1VQ0yOsY"}, {"id": "bangna", "title": "PTG Station Bang Na", "province": "Samut Prakan", "traffic_level": "high", "spaces_count": 1, "lat": 13.674, "lng": 100.593, "location": "Samut Prakan \\u00b7 12.8 km away", "traffic_badge": "High Traffic", "match_badge": "85% Match", "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuCA1MuAJaNhJiEsiDcqskadl4jthvCv3RRv8V3kePz311obEN72Bl5XlnODxBKTtH2HcQQ81ZgsvXMaj3PbOS_l8tndMBg_nuwhVyxl9SukBnO91yFKDU6kxOuu951CaFp80ln54VmlOKK9KZnl7L-imZ5qj675tbgYkJiDd0PImdorHHiJxO67x6IvhB9xtpEI0lpiYXeiuWA2iEn2BEvZytquIlJ2d7iJLov2gJt7eUgkRa65IEKjLmfzYoefpJ7EI-h7lCe-KKo"}];

      const stationTooltipHtml = (m) => {
        return \`
          <div style="width: 240px;">
            <div style="display:flex; gap:10px; align-items:flex-start;">
              <img src="\${m.image}" alt="\${m.title}" style="width:64px; height:48px; object-fit:cover; border-radius:10px;" />
              <div style="flex:1; min-width:0;">
                <div style="font-weight:800; font-family: inherit; font-size:13px; margin-top:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                  \${m.title}
                </div>
                <div style="font-size:12px; opacity:0.8; margin-top:2px;">
                  \${m.location}
                </div>
                <div style="display:flex; gap:6px; margin-top:8px; flex-wrap:wrap;">
                  <span style="background: rgba(70,104,0,0.15); color:#466800; padding:2px 8px; border-radius:999px; font-weight:700; font-size:10px;">
                    \${m.traffic_badge}
                  </span>
                  <span style="background:#466800; color:#fff; padding:2px 8px; border-radius:999px; font-weight:800; font-size:10px;">
                    \${m.match_badge}
                  </span>
                </div>
              </div>
            </div>
          </div>
        \`;
      };

      const destinationIcon = (fill) => {
        // Simple “destination” pin via inline SVG for a Google Maps-like look.
        return L.divIcon({
          className: '',
          iconSize: [30, 42],
          iconAnchor: [15, 42],
          popupAnchor: [0, -42],
          html: \`
            <div style="width:30px; height:42px; position:relative;">
              <svg width="30" height="42" viewBox="0 0 30 42" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 0C9.05 0 4.25 4.8 4.25 10.75C4.25 20.5 15 42 15 42C15 42 25.75 20.5 25.75 10.75C25.75 4.8 20.95 0 15 0Z" fill="\${fill}" />
                <circle cx="15" cy="12" r="5" fill="#FFFFFF" opacity="0.95"/>
              </svg>
            </div>
          \`
        });
      };

      const init = () => {
        const el = document.getElementById("ptg-explore-leaflet-map");
        if (!el) return false;
        if (!window.L) return false;
        // When navigating in SPA mode, the map container can be re-rendered.
        // If we already initialized Leaflet for a previous DOM node, re-bind to the new one.
        if (
          window.__ptgExploreMap &&
          window.__ptgExploreMap.getContainer &&
          window.__ptgExploreMap.getContainer() === el
        ) {
          try { window.__ptgExploreMap.invalidateSize(); } catch (e) {}
          return true;
        }

        if (window.__ptgExploreMap && window.__ptgExploreMap.remove) {
          try { window.__ptgExploreMap.remove(); } catch (e) {}
        }
        window.__ptgExploreMap = null;
        window.__ptgExploreMapInited = false;

        // Leaflet can throw if the container was previously initialized.
        try {
          if (el._leaflet_id) delete el._leaflet_id;
        } catch (e) {
          el._leaflet_id = undefined;
        }

        const map = L.map(el, { zoomControl: false }).setView([13.7563, 100.5018], 10);
        window.__ptgExploreMap = map;
        window.__ptgExploreMapInited = true;

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "© OpenStreetMap contributors"
        }).addTo(map);

        const icon = destinationIcon("#466800");
        const userIcon = destinationIcon("#ef4444");
        const stationMarkers = [];

        markers.forEach((m, idx) => {
          const marker = L.marker([m.lat, m.lng], { icon }).addTo(map);
          stationMarkers.push({ marker, data: m });

          const html = stationTooltipHtml(m);
          marker.bindTooltip(html, {
            direction: 'top',
            offset: [0, -24],
            opacity: 1,
            sticky: true,
            className: 'ptg-leaflet-tooltip'
          });
          marker.on('mouseover', () => marker.openTooltip());
          marker.on('mouseout', () => marker.closeTooltip());

          // Click should behave like “select station” - open tooltip and highlight.
          marker.on('click', () => {
            marker.openTooltip();
          });
        });

        let userPin = null;

        const zoomInBtn = document.getElementById("ptg-explore-zoom-in-btn");
        const zoomOutBtn = document.getElementById("ptg-explore-zoom-out-btn");
        const locBtn = document.getElementById("ptg-explore-loc-btn");

        if (zoomInBtn) {
          zoomInBtn.addEventListener("click", () => map.zoomIn());
        }
        if (zoomOutBtn) {
          zoomOutBtn.addEventListener("click", () => map.zoomOut());
        }

        if (locBtn) {
          locBtn.addEventListener('click', () => {
            if (!navigator.geolocation) return;
            navigator.geolocation.getCurrentPosition((pos) => {
              const latlng = { lat: pos.coords.latitude, lng: pos.coords.longitude };
              map.setView([latlng.lat, latlng.lng], 13);

              // Replace the previous user pin (red).
              if (userPin) {
                map.removeLayer(userPin);
              }
              userPin = L.marker([latlng.lat, latlng.lng], { icon: userIcon }).addTo(map);
              userPin.bindTooltip("Your location", {
                direction: "top",
                offset: [0, -24],
                sticky: true,
              }).openTooltip();
            });
          });
        }

        // After route changes/layout, ensure Leaflet recalculates dimensions.
        setTimeout(() => {
          try { map.invalidateSize(); } catch (e) {}
        }, 120);
        setTimeout(() => {
          try { map.invalidateSize(); } catch (e) {}
        }, 420);

        // Filtering: hide/show station cards and map markers together.
        const provinceSelect = document.getElementById("ptg-explore-filter-province");
        const trafficSelect = document.getElementById("ptg-explore-filter-traffic");
        const spacesSelect = document.getElementById("ptg-explore-filter-spaces");
        const searchInput = document.getElementById("ptg-explore-search-input");

        const provinceValues = Array.from(new Set(markers.map((m) => m.province).filter(Boolean)));
        const provinceValuesLower = provinceValues.map((p) => p.toLowerCase());

        const applyFilters = () => {
          const provinceVal = provinceSelect?.value ?? "all";
          const trafficVal = trafficSelect?.value ?? "all";
          const spacesVal = spacesSelect?.value ?? "all";

          const minSpaces = spacesVal === "all" ? null : parseInt(spacesVal, 10);
          const searchVal = (searchInput?.value ?? "").trim().toLowerCase();
          const provinceOnlyMatch = !!searchVal && provinceValuesLower.includes(searchVal);

          // Update map markers.
          stationMarkers.forEach((item) => {
            const m = item.data;
            const okProvince = provinceVal === "all" || m.province === provinceVal;
            const okTraffic = trafficVal === "all" || m.traffic_level === trafficVal;
            const okSpaces = minSpaces === null || m.spaces_count >= minSpaces;
            const okSearch = !searchVal
              ? true
              : provinceOnlyMatch
                ? (m.province || "").toLowerCase() === searchVal
                : (\`\${m.title || ""} \${m.province || ""} \${m.location || ""}\`).toLowerCase().includes(searchVal);

            const match = okProvince && okTraffic && okSpaces && okSearch;

            if (match) {
              item.marker.addTo(map);
            } else {
              map.removeLayer(item.marker);
              item.marker.closeTooltip?.();
            }
          });

          // Update right-side station list.
          const cards = document.querySelectorAll('[id^="ptg-station-card-"]');
          cards.forEach((card) => {
            const cardProvince = card.getAttribute("data-province") ?? "";
            const cardTraffic = card.getAttribute("data-traffic") ?? "";
            const cardSpacesStr = card.getAttribute("data-spaces") ?? "0";
            const cardSpaces = parseInt(cardSpacesStr, 10);

            const okProvince = provinceVal === "all" || cardProvince === provinceVal;
            const okTraffic = trafficVal === "all" || cardTraffic === trafficVal;
            const okSpaces = minSpaces === null || cardSpaces >= minSpaces;
            const cardText = (card.textContent ?? "").toLowerCase();
            const cardProvinceLower = (cardProvince || "").toLowerCase();
            const okSearch = !searchVal
              ? true
              : provinceOnlyMatch
                ? cardProvinceLower === searchVal
                : cardText.includes(searchVal);

            const match = okProvince && okTraffic && okSpaces && okSearch;

            card.style.display = match ? "" : "none";
          });
        };

        if (provinceSelect) provinceSelect.addEventListener("change", applyFilters);
        if (trafficSelect) trafficSelect.addEventListener("change", applyFilters);
        if (spacesSelect) spacesSelect.addEventListener("change", applyFilters);
        if (searchInput) searchInput.addEventListener("input", applyFilters);
        applyFilters();
        // Ensure the station cards are in the DOM before the first pass.
        setTimeout(applyFilters, 250);

        try {
          map.invalidateSize();
        } catch (e) {}

        return true;
      };

      const tries = 25;
      let i = 0;
      const tick = () => {
        const ok = init();
        if (ok) return;
        i += 1;
        if (i < tries) setTimeout(tick, 150);
      };
      tick();
    })();
    `))),u(`div`,{className:`absolute bottom-8 left-8 flex flex-col gap-2 z-10`},u(`button`,{className:`bg-white p-3 rounded-xl shadow-xl hover:bg-surface-container-low transition-colors text-on-surface-variant cursor-pointer`,id:`ptg-explore-zoom-in-btn`,ref:n,title:`Zoom in`,type:`button`},u(`span`,{className:`material-symbols-outlined`},`add`)),u(`button`,{className:`bg-white p-3 rounded-xl shadow-xl hover:bg-surface-container-low transition-colors text-on-surface-variant cursor-pointer`,id:`ptg-explore-zoom-out-btn`,ref:r,title:`Zoom out`,type:`button`},u(`span`,{className:`material-symbols-outlined`},`remove`)),u(`button`,{className:`bg-white p-3 rounded-xl shadow-xl hover:bg-surface-container-low transition-colors text-primary cursor-pointer`,id:`ptg-explore-loc-btn`,ref:d,title:`My location`,type:`button`},u(`span`,{className:`material-symbols-outlined text-primary`},`my_location`)))),u(`section`,{},u(a,{className:`w-[480px] h-full bg-white flex flex-col shadow-2xl z-10`},u(a,{className:`p-6 border-b border-surface-container`},u(`div`,{className:`flex items-center justify-between mb-6`},u(`div`,{className:``},u(`h1`,{className:`text-2xl font-serif font-bold text-on-surface tracking-tight`},`Browse Locations`),u(`p`,{className:`text-sm text-outline mt-1`},`Showing 1,247 locations across Thailand`)),u(`button`,{className:`p-2 border border-outline-variant rounded-xl hover:bg-surface-container-low transition-colors`,type:`button`},u(`span`,{className:`material-symbols-outlined text-on-surface-variant`},`tune`))),u(`div`,{className:`flex flex-wrap gap-2`},u(`div`,{className:`relative`},u(`select`,{className:`appearance-none bg-surface-container-low border-none rounded-full px-4 py-2 text-xs font-medium pr-8 focus:ring-1 focus:ring-primary/30 cursor-pointer`,id:`ptg-explore-filter-province`,ref:f},u(`option`,{value:`all`},`All Provinces`),u(`option`,{value:`Bangkok`},`Bangkok`),u(`option`,{value:`Nonthaburi`},`Nonthaburi`),u(`option`,{value:`Pathum Thani`},`Pathum Thani`),u(`option`,{value:`Samut Prakan`},`Samut Prakan`)),u(`span`,{className:`material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-[16px] pointer-events-none text-outline cursor-pointer`},`expand_more`)),u(`div`,{className:`relative`},u(`select`,{className:`appearance-none bg-surface-container-low border-none rounded-full px-4 py-2 text-xs font-medium pr-8 focus:ring-1 focus:ring-primary/30 cursor-pointer`,id:`ptg-explore-filter-traffic`,ref:p},u(`option`,{value:`all`},`All Traffic`),u(`option`,{value:`high`},`High`),u(`option`,{value:`medium`},`Medium`),u(`option`,{value:`low`},`Low`)),u(`span`,{className:`material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-[16px] pointer-events-none text-outline cursor-pointer`},`expand_more`)),u(`div`,{className:`relative`},u(`select`,{className:`appearance-none bg-surface-container-low border-none rounded-full px-4 py-2 text-xs font-medium pr-8 focus:ring-1 focus:ring-primary/30 cursor-pointer`,id:`ptg-explore-filter-spaces`,ref:m},u(`option`,{value:`all`},`All Spaces`),u(`option`,{value:`2`},`2+ Spaces`),u(`option`,{value:`5`},`5+ Spaces`),u(`option`,{value:`10`},`10+ Spaces`)),u(`span`,{className:`material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-[16px] pointer-events-none text-outline cursor-pointer`},`expand_more`)))),u(`div`,{className:`flex-1 overflow-y-auto p-6 space-y-6`},u(`div`,{className:`group bg-white rounded-xl border border-transparent hover:border-primary/20 hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer`,"data-province":`Bangkok`,"data-spaces":`3`,"data-station-id":`latphrao71`,"data-traffic":`high`,id:`ptg-station-card-latphrao71`,ref:h},u(`div`,{className:`relative h-40 overflow-hidden`},u(`img`,{alt:`PTG Station Lat Phrao 71`,className:`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105`,src:`https://lh3.googleusercontent.com/aida-public/AB6AXuAogYrPXv2k3xHfrvbGuzO2u9H021UfnjMDMLdrEuLu2gcWwSPbve71JZORUMDDO8zIqCI0qJ1BsPvzeI2XvXsUIlY9K58cfYcjOMUAWR2_i49F1_jWhThLLarbsBYMgxgc4v0VRqRj9eIjeaYHEFJuJHKGOCdjYH-9rNAX2Nh5sR-96NsIkkQicdlwhVgxMatMoIjNU8gdA3_D_drXtDmqGuAEX8DPF9T8cRvga1fGTTE_a2KHsAQ5jWufQ47tXLdN87UwcjOhK4Q`}),u(`div`,{className:`absolute top-3 left-3 flex gap-2`},u(`span`,{className:`bg-white/90 backdrop-blur px-2.5 py-1 rounded-full text-[10px] font-bold text-primary flex items-center gap-1 uppercase tracking-wider`},u(`span`,{className:`material-symbols-outlined text-[12px] fill-icon`},`verified`),` PTG Verified`),u(`span`,{className:`bg-primary text-white px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 uppercase tracking-wider`},`98% Match`)),u(`button`,{className:`absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur text-white flex items-center justify-center hover:bg-white hover:text-error transition-all cursor-pointer`,type:`button`},u(`span`,{className:`material-symbols-outlined text-sm`},`favorite`))),u(`div`,{className:`p-5`},u(`div`,{className:`flex justify-between items-start mb-2`},u(`div`,{},u(`h3`,{className:`font-serif text-lg font-bold text-on-surface`},`PTG Station Lat Phrao 71`),u(`p`,{className:`text-xs text-outline font-medium`},`Bangkok · 2.4 km away`)),u(`span`,{className:`bg-on-secondary-container/10 text-on-secondary-container px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-tighter`},`High Traffic`)),u(`div`,{className:`grid grid-cols-2 gap-4 my-4`},u(`div`,{className:`flex items-center gap-2`},u(`span`,{className:`material-symbols-outlined text-primary text-lg`},`aspect_ratio`),u(`div`,{},u(`p`,{className:`text-[10px] text-outline uppercase font-bold tracking-widest`},`Max Area`),u(`p`,{className:`text-sm font-bold text-on-surface`},`45 sqm`))),u(`div`,{className:`flex items-center gap-2`},u(`span`,{className:`material-symbols-outlined text-primary text-lg`},`storefront`),u(`div`,{},u(`p`,{className:`text-[10px] text-outline uppercase font-bold tracking-widest`},`Available`),u(`p`,{className:`text-sm font-bold text-on-surface`},`3 Spaces`)))),u(`div`,{className:`flex gap-2 pt-2`},u(`button`,{className:`flex-1 bg-gradient-to-tr from-primary to-primary-container text-white text-xs font-bold py-3 rounded-lg hover:brightness-110 transition-all active:scale-95`,type:`button`},`View Details`)))),u(`div`,{className:`group bg-white rounded-xl border border-transparent hover:border-primary/20 hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer`,"data-province":`Bangkok`,"data-spaces":`5`,"data-station-id":`ramaix`,"data-traffic":`medium`,id:`ptg-station-card-ramaix`,ref:g},u(`div`,{className:`relative h-40 overflow-hidden`},u(`img`,{alt:`PTG Station Rama IX`,className:`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105`,src:`https://lh3.googleusercontent.com/aida-public/AB6AXuB1XxKMY6FJqo6lJ8jPB-SDQcmEdz1BGe1moAtnxPkXaE82_zwaznYWAnNMvLgUTjz3bkjFvZeSOD-qBHB6XnZmYHrz9yTFk8xIw2xJWi8aN23rFnPM54otIauhJHSX5S_Uhz9OcmG9tRBR2XpLp0qdbts3bwiDPzho2Es8p_WCV7x1v_1HQ0UVhh4AjPQcbJKfIrLX3yFBdzQxm9pSBNvFh_kw6Ge_u_v818HARIcLfsm_P3S4Ku7CyHiA0rGDHIOLCRR1VQ0yOsY`}),u(`div`,{className:`absolute top-3 left-3 flex gap-2`},u(`span`,{className:`bg-white/90 backdrop-blur px-2.5 py-1 rounded-full text-[10px] font-bold text-primary flex items-center gap-1 uppercase tracking-wider`},u(`span`,{className:`material-symbols-outlined text-[12px] fill-icon`},`verified`),` PTG Verified`),u(`span`,{className:`bg-primary text-white px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 uppercase tracking-wider`},`92% Match`)),u(`button`,{className:`absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur text-white flex items-center justify-center hover:bg-white hover:text-error transition-all cursor-pointer`,type:`button`},u(`span`,{className:`material-symbols-outlined text-sm`},`favorite`))),u(`div`,{className:`p-5`},u(`div`,{className:`flex justify-between items-start mb-2`},u(`div`,{},u(`h3`,{className:`font-serif text-lg font-bold text-on-surface`},`PTG Station Rama IX`),u(`p`,{className:`text-xs text-outline font-medium`},`Bangkok · 5.1 km away`)),u(`span`,{className:`bg-tertiary-container/20 text-on-tertiary-container px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-tighter`},`Medium Traffic`)),u(`div`,{className:`grid grid-cols-2 gap-4 my-4`},u(`div`,{className:`flex items-center gap-2`},u(`span`,{className:`material-symbols-outlined text-primary text-lg`},`aspect_ratio`),u(`div`,{},u(`p`,{className:`text-[10px] text-outline uppercase font-bold tracking-widest`},`Max Area`),u(`p`,{className:`text-sm font-bold text-on-surface`},`120 sqm`))),u(`div`,{className:`flex items-center gap-2`},u(`span`,{className:`material-symbols-outlined text-primary text-lg`},`storefront`),u(`div`,{},u(`p`,{className:`text-[10px] text-outline uppercase font-bold tracking-widest`},`Available`),u(`p`,{className:`text-sm font-bold text-on-surface`},`5 Spaces`)))),u(`div`,{className:`flex gap-2 pt-2`},u(`button`,{className:`flex-1 bg-gradient-to-tr from-primary to-primary-container text-white text-xs font-bold py-3 rounded-lg hover:brightness-110 transition-all active:scale-95`,type:`button`},`View Details`)))),u(`div`,{className:`group bg-white rounded-xl border border-transparent hover:border-primary/20 hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer`,"data-province":`Samut Prakan`,"data-spaces":`1`,"data-station-id":`bangna`,"data-traffic":`high`,id:`ptg-station-card-bangna`,ref:_},u(`div`,{className:`relative h-40 overflow-hidden`},u(`img`,{alt:`PTG Station Bang Na`,className:`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105`,src:`https://lh3.googleusercontent.com/aida-public/AB6AXuCA1MuAJaNhJiEsiDcqskadl4jthvCv3RRv8V3kePz311obEN72Bl5XlnODxBKTtH2HcQQ81ZgsvXMaj3PbOS_l8tndMBg_nuwhVyxl9SukBnO91yFKDU6kxOuu951CaFp80ln54VmlOKK9KZnl7L-imZ5qj675tbgYkJiDd0PImdorHHiJxO67x6IvhB9xtpEI0lpiYXeiuWA2iEn2BEvZytquIlJ2d7iJLov2gJt7eUgkRa65IEKjLmfzYoefpJ7EI-h7lCe-KKo`}),u(`div`,{className:`absolute top-3 left-3 flex gap-2`},u(`span`,{className:`bg-white/90 backdrop-blur px-2.5 py-1 rounded-full text-[10px] font-bold text-primary flex items-center gap-1 uppercase tracking-wider`},u(`span`,{className:`material-symbols-outlined text-[12px] fill-icon`},`verified`),` PTG Verified`),u(`span`,{className:`bg-primary text-white px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 uppercase tracking-wider`},`85% Match`)),u(`button`,{className:`absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur text-white flex items-center justify-center hover:bg-white hover:text-error transition-all cursor-pointer`,type:`button`},u(`span`,{className:`material-symbols-outlined text-sm`},`favorite`))),u(`div`,{className:`p-5`},u(`div`,{className:`flex justify-between items-start mb-2`},u(`div`,{},u(`h3`,{className:`font-serif text-lg font-bold text-on-surface`},`PTG Station Bang Na`),u(`p`,{className:`text-xs text-outline font-medium`},`Samut Prakan · 12.8 km away`)),u(`span`,{className:`bg-secondary-container/30 text-on-secondary-container px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-tighter`},`High Traffic`)),u(`div`,{className:`grid grid-cols-2 gap-4 my-4`},u(`div`,{className:`flex items-center gap-2`},u(`span`,{className:`material-symbols-outlined text-primary text-lg`},`aspect_ratio`),u(`div`,{},u(`p`,{className:`text-[10px] text-outline uppercase font-bold tracking-widest`},`Max Area`),u(`p`,{className:`text-sm font-bold text-on-surface`},`32 sqm`))),u(`div`,{className:`flex items-center gap-2`},u(`span`,{className:`material-symbols-outlined text-primary text-lg`},`storefront`),u(`div`,{},u(`p`,{className:`text-[10px] text-outline uppercase font-bold tracking-widest`},`Available`),u(`p`,{className:`text-sm font-bold text-on-surface`},`1 Space`)))),u(`div`,{className:`flex gap-2 pt-2`},u(`button`,{className:`flex-1 bg-gradient-to-tr from-primary to-primary-container text-white text-xs font-bold py-3 rounded-lg hover:brightness-110 transition-all active:scale-95`,type:`button`},`View Details`)))))))),u(`div`,{className:`fixed bottom-8 right-[500px] z-10 pointer-events-none`},u(`button`,{className:`pointer-events-auto bg-on-surface text-white px-6 py-4 rounded-full shadow-2xl flex items-center gap-3 transform transition-transform hover:scale-105 active:scale-95`,type:`button`},u(`span`,{className:`material-symbols-outlined fill-icon`},`analytics`),u(`span`,{className:`text-sm font-bold tracking-tight`},`Open Market Insights`))))),u(`title`,{},`PTG Retail Platform | Explore Locations`),u(`meta`,{content:`favicon.ico`,property:`og:image`}))});export{pe as default};